from django.views.decorators.csrf import csrf_exempt
from utils.auth import login_required_json
from utils.db import get_db_connection
from django.http import JsonResponse
import os, uuid, json
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage

@csrf_exempt
@login_required_json
def create_comment(request):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        data = json.loads(request.body)
        post_id = data['post_id']
        comment_content = data['comment']  # Changed to `comment_content` to match your schema

        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            
            # Insert data into the comment table, also setting a default value for `is_blurred` (e.g., 0)
            cursor.execute("""
                INSERT INTO comment (post_id, user_id, content, is_blurred)
                VALUES (%s, %s, %s, %s)
                RETURNING comment_id
            """, (post_id, user_id, comment_content, 0))  # Assuming `is_blurred` is 0 (not blurred)
            conn.commit()
            comment_id = cursor.lastrowid

            cursor.execute("""
                SELECT c.comment_id, c.content, u.first_name
                FROM comment c
                JOIN user u ON c.user_id = u.user_id
                WHERE c.comment_id = %s
            """, (comment_id,))
            new_comment = cursor.fetchone()

            return JsonResponse({
                'message': 'Comment added',
                'comment': {
                    'comment_id': new_comment[0],
                    'content': new_comment[1],
                    'first_name': new_comment[2],
                }
            })
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
        finally:
            if 'cursor' in locals(): cursor.close()
            if 'conn' in locals(): conn.close()
    
    return JsonResponse({'error': 'Invalid method'}, status=405)
