import React, { useState, useEffect } from 'react';
import { PermMedia } from '@mui/icons-material';
import '../styles/componentStyles/share.css';
import axios from 'axios';

function Share() {
    const [postText, setPostText] = useState('');
    const [file, setFile] = useState(null);
    const [filePreview, setFilePreview] = useState(null);
    const [userData, setUserData] = useState(null);

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        setFile(selectedFile);
        setFilePreview(URL.createObjectURL(selectedFile));
    };

    useEffect(() => {
    const fetchUser = async () => {
      try {
        const res = await axios.get("http://localhost:8000/api/auth/user/", {
          withCredentials: true,
        });
        setUserData(res.data.user);
      } catch (err) {
        console.error("Error fetching profile data:", err);
      }
    };
        fetchUser();
    }, []);

    const handleSubmit = async () => {
        if (!postText && !file) return;

        const formData = new FormData();
        formData.append('caption', postText);
        if (file) {
            formData.append('image', file);
        }

        try {
            const response = await fetch('/api/posts/create/', {
                method: 'POST',
                credentials: 'include',
                body: formData
            });

            if (response.ok) {
                setPostText('');
                setFile(null);
                setFilePreview(null);
                // Optionally refresh feed
            } else {
                console.error("Post failed");
            }
        } catch (error) {
            console.error("Error submitting post:", error);
        }
    };
    const profilePicUrl = userData?.profile_picture
    ? `http://localhost:8000/media/${userData.profile_picture}`
    : '/assets/default_profile.png';


    return (
        <div className="share">
            <div className="shareWrapper">
                <div className="shareTop">
                    { userData && (
                        <img src= {profilePicUrl} 
                        alt=""
                        className="shareProfileImg"
                        />
                    )}
                    <input 
                        placeholder="What's on your mind?" 
                        className="shareInput" 
                        value={postText}
                        onChange={(e) => setPostText(e.target.value)}
                    />
                </div>
                <hr className="shareHr" />
                <div className="shareBottom">
                    <div className="shareOptions">
                        <label className="shareOption">
                            <PermMedia htmlColor="tomato" className="shareIcon" />
                            <span className="shareOptionText">Photo</span>
                            <input 
                                type="file" 
                                className="shareOptionInput" 
                                onChange={handleFileChange} 
                                style={{ display: 'none' }}
                            />
                        </label>
                    </div>
                    <button className="shareButton" onClick={handleSubmit}>Post</button>
                </div>
                {filePreview && <img src={filePreview} alt="preview" className="shareImg" />}
            </div>
        </div>
    );
}

export default Share;
